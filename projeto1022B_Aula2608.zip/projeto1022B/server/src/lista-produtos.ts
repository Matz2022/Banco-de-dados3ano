//Classes
import mysql, { RowDataPacket } from 'mysql2/promise';

type Output ={
    id:number,
    nome:string,
    descricao:string, 
    preco:number,
    imagem:string
}
class ListaProdutos{
    async execute(){
        const connection = await  mysql.createConnection({
            host: 'localhost',
            user: 'root',
            database: 'banco1022b',
          });
          return connection
          .then((conn)=>{
             // console.log("Conectou no banco de dados")
          
             //Prepara uma query para execução:
             const queryPreparada = await connection.prepare("SELECT * FROM produtos");
             return queryPreparada
             .then((query)=>{
                 const queryExecutada = query.execute([])
                 return queryExecutada

                 .then((result)=>{
                     const [linhas ,campus] = result
                     const dados = linhas as RowDataPacket[]
                     const listaProdutos:Output[] = []
                     for(let i=0;i<dados.length;i++){
                         console.log(dados[i].id,dados[i].nome)
                         const produto ={
                            id:dados[i].id,
                            nome:dados[i].nome,
                            descricao:dados[i].descricao,
                            preco: parseFloat(dados[i].preco),
                            imagem:dados[i].imagem,
                        }
                        listaProdutos.push(produto)
                     }
                     return listaProdutos
                 })
                 .catch((err)=>console.log("Erro:",err))
             })
             .catch((err)=> {
              if(err.code==='ER_NO_SUCH_TABLE'){
                  console.log("ERRO: VOCÊ DEVE CRIAR A TABELA PRODUTOS NO WORKBENCH")
              } else if(err.code==='ER_PARSE_ERROR'){
               console.log("ERRO: Você digitou algo errado na query, confira a escrita, virgulas, nome das colunas e posição chaves.")
              }else{
                  console.log("Erro não tratado:",err);
              }
             })
          }) //SE DEU CERTO (v)
          .catch((erro)=>{
              if(erro.code === 'ECONNREFUSED'){
                  console.log("liga o LARAGON !")
              } else if(erro.code === 'ER_BAD_DB_ERROR'){
                  console.log(" ERRO: você não criou o banco de dados 'banco1022B' no workbench!")
              }else {
                  console.log(erro)
              }
          })//SE DEU ERRADO
          
    }
}
export default ListaProdutos;